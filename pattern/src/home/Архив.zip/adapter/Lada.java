package home.adapter;

public class Lada implements Movable {
    @Override
    public double getSpeed() {
        return 80;
    }
}
