package home.adapter;

public interface MovableAdapter {
    /**
     *
     * @return KMPH
     */
    double getSpeed();
}
