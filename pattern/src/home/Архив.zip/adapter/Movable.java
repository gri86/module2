package home.adapter;

public interface Movable {
    /**
     *
     * @return MPH
     */
    double getSpeed();
}
