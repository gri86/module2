package home.adapter;

public class BMW implements Movable {
    @Override
    public double getSpeed() {
        return 160;
    }
}
