package home.adapter;

public class AdapterApp {
    public static void main(String[] args) {
    }
}
