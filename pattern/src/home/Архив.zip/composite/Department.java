package home.composite;

public interface Department {

    void printDepartment();
}
