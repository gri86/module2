package home.facade;

public class MPEG4CompressionCodec implements Codec {
    public String type = "mp4";

}
