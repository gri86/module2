package home.facade;

public interface Codec {
}
